runif <-
function (n, min = 0, max = 1) 
.Internal(runif(n, min, max))
